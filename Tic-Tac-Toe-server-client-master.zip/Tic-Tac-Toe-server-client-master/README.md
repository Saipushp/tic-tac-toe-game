# Tic-Tac-Toe-server-client

<h3>Synopsis </h3>
<p>Application is written in Java. It is distributed Tic Tac Toe game developed by multithreading concept and networking with socket streams. It enables users to play on different machines from anywhere on the Internet. Server creates a server socket and accepts connections from two players to form a session. Server can form any number of sessions.</p>

<h3>Reference </h3>
<p>Introduction to Java Programming - COMPREHENSIVE VERSION Eight Edition, Y. Daniel Liang</p>

<h3>Tests </h3>
<p>To run it locally, host have to be "localhost". Download the project and run the project. Server is going to start. Then run the applet Client.java. Keep in mind that Client.java is an applet without main method and you have to run it as a file. Run it two times in order to form a first session of players.</p>
<p>Youtube video soon... </p>
